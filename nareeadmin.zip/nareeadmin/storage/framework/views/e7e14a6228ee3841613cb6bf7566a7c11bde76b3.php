<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Name Event :</strong>
            <?php echo Form::text('name_event', null, array('placeholder' => 'Name Event','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>description :</strong>
            <?php echo Form::textarea('description', null, array('placeholder' => 'Fill description...','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Date Event :</strong>
            <?php echo Form::date('date_event', null, array('placeholder' => 'dd/mm/yyyy','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Province :</strong>
            <?php echo Form::text('province', null, array('placeholder' => 'Example : DKI Jakarta','class' => 'form-control')); ?>

        </div>
    </div>
    
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Organizer:</strong>
            <?php echo Form::text('organizer', null, array('placeholder' => 'organizer','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Dance Type :</strong>
            <?php echo Form::text('dance_type', null, array('placeholder' => 'dance_type','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Duration :</strong>
            <?php echo Form::text('duration', null, array('placeholder' => 'example : 2 hari','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Longitude :</strong>
            <?php echo Form::text('long', null, array('placeholder' => 'Longitude','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Latitude :</strong>
            <?php echo Form::text('lat', null, array('placeholder' => 'Latitude','class' => 'form-control')); ?>

        </div>
    </div>


    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group <?php echo $errors->has('poster') ? 'has-error' : ''; ?>">
            <strong>Poster :</strong>
            <?php echo Form::file('poster'); ?>

            <?php echo Form::label('poster', 'Gambar Harus Memiliki Format ( jpg,jpeg,png )*'); ?>

        </div>
    </div>

    <!-- <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Foto:</strong>
            <?php echo Form::file('foto', null); ?>

        </div>
    </div> -->


    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>