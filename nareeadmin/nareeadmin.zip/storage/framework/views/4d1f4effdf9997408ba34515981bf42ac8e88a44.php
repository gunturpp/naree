<!DOCTYPE html>
<html>
<?php echo $__env->make('dashboard.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        advertisement
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">advertisement</li>
      </ol>
    </section>
 
    <section class="content">
        <div class="row">
                <div class="col-lg-12 margin-tb">
                    <div class="pull-left">
                        <h2>advertisement list</h2>
                    </div>
                    <div class="pull-right">
                        <a class="btn btn-success" href="<?php echo e(route('advertisement.create')); ?>"> Create New advertisement</a>
                    </div>
                </div>
            </div>

            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>

            <table class="table table-bordered">
                <tr>
                    <th>No</th>
                    <th>Title</th>
                    <th>status</th>
                    <th>duration</th>
                    <th>created_at</th>
                    <th width="280px">Action</th>
                </tr>
            <?php $__currentLoopData = $advertisements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertisement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($advertisement->title); ?></td>
                <td><img src="<?php echo e($advertisement -> poster); ?>" style="height:50px;width:50px;text-align:center"></td>
                <td><?php echo e($advertisement->status); ?></td>
                <td><?php echo e($advertisement->duration); ?></td>
                <td><?php echo e($advertisement->created_at); ?></td>
                <td>
                    <a class="btn btn-info" href="<?php echo e(route('advertisement.show',$advertisement->id)); ?>">Show</a>
                    <a class="btn btn-primary" href="<?php echo e(route('advertisement.edit',$advertisement->id)); ?>">Edit</a>
                    <?php echo Form::open(['method' => 'DELETE','route' => ['advertisement.destroy', $advertisement->id],'style'=>'display:inline']); ?>

                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            
            <?php echo $advertisements->links(); ?>

    </section>
</div>

<?php echo $__env->make('dashboard.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
</body>
</html>
