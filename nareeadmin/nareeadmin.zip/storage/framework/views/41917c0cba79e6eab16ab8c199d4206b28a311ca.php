<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>kehadiran :</strong>
            
            <?php echo Form::select('kehadiran', ['0' => 'Cancel', '1' => 'Pending', '2' => 'Hadir']); ?>

        </div>
    </div>



    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>