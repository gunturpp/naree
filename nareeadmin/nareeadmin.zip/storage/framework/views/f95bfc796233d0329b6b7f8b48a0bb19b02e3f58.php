<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Title :</strong>
            <?php echo Form::text('judul_news', null, array('placeholder' => 'Judul Berita','class' => 'form-control')); ?>

        </div>
    </div>
    
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Description:</strong>
            <?php echo Form::textarea('description', null, array('placeholder' => 'deskripsi','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group <?php echo $errors->has('image') ? 'has-error' : ''; ?>">
            <strong>image:</strong>
            <?php echo Form::file('image'); ?>

            <?php echo Form::label('image', 'Gambar Harus Memiliki Format ( jpg,jpeg,png )*'); ?>

        </div>
    </div>
    <!-- <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>image:</strong>
            <?php echo Form::file('image', null); ?>

        </div>
    </div> -->

    <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>