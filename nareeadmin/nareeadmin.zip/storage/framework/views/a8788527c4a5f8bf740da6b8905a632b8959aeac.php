<?php $__env->startSection('content'); ?>

<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="pull-right" style="margin-top:15px;">
                        <a class="btn btn-primary" href="<?php echo e(route('kehadiran.index')); ?>"> Back</a>
                    </div>
                    <div class="col-lg-12">
                        <center><h1 class="page-header">kehadiran Data Detail</h1></center>
                    </div>
            </div>
            
        </div>
    </div>

    <div style="width: 80%; margin: auto;">
      	<table class="table centered">

            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>id user :</strong>
                        <?php echo e($kehadiran_event->id_user); ?>

                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>id_event :</strong>
                        <?php echo e($kehadiran_event->id_event); ?>

                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>status kehadiran :</strong>
                        <?php echo e($kehadiran_event->kehadiran); ?>

                    </div>
                </div>
            </div>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>