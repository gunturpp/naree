<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>title :</strong>
            <?php echo Form::text('title', null, array('placeholder' => 'title','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>scope :</strong>
            <?php echo Form::text('scope', null, array('placeholder' => 'Internasional/Nasional/Regional','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Month :</strong>
            
            <?php echo Form::selectMonth('month', 1, ['class' => 'field']); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Year :</strong>
            
            <?php echo Form::selectYear('year', 1970, 2018); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>exp :</strong>
            <?php echo Form::number('exp', null, array('placeholder' => '100','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group <?php echo $errors->has('poster') ? 'has-error' : ''; ?>">
            <strong>Poster :</strong>
            <?php echo Form::file('poster'); ?>

            <?php echo Form::label('poster', 'Gambar Harus Memiliki Format ( jpg,jpeg,png )*'); ?>

        </div>
    </div>

    <!-- <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Foto:</strong>
            <?php echo Form::file('foto', null); ?>

        </div>
    </div> -->


    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>