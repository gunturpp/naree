<!DOCTYPE html>
<html>
<?php echo $__env->make('dashboard.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        achievement
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">achievement</li>
      </ol>
    </section>
 
    <section class="content">
        <div class="row">
                <div class="col-lg-12 margin-tb">
                    <div class="pull-left">
                        <h2>achievement list</h2>
                    </div>
                    <div class="pull-right">
                        <a class="btn btn-success" href="<?php echo e(route('achievement.create')); ?>"> Create New achievement</a>
                    </div>
                </div>
            </div>

            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>

            <table class="table table-bordered">
                <tr>
                    <th>No</th>
                    <th>Title</th>
                    <th>Certificate</th>
                    <th>Month/Year</th>
                    <th>created_at</th>
                    <th width="280px">Action</th>
                </tr>
            <?php $__currentLoopData = $achievements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($achievement->title); ?></td>
                <td><img src="<?php echo e($achievement -> poster); ?>" style="height:50px;width:50px;text-align:center"></td>
                <td><?php echo e($achievement->month); ?><?php echo e($achievement->year); ?></td>
                <td><?php echo e($achievement->created_at); ?></td>
                <td>
                    <a class="btn btn-info" href="<?php echo e(route('achievement.show',$achievement->id)); ?>">Show</a>
                    <a class="btn btn-primary" href="<?php echo e(route('achievement.edit',$achievement->id)); ?>">Edit</a>
                    <?php echo Form::open(['method' => 'DELETE','route' => ['achievement.destroy', $achievement->id],'style'=>'display:inline']); ?>

                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            
            <?php echo $achievements->links(); ?>

    </section>
</div>

<?php echo $__env->make('dashboard.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
</body>
</html>
