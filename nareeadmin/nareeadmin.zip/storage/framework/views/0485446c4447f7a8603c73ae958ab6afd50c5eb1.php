<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>title :</strong>
            <?php echo Form::text('title', null, array('placeholder' => 'title','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>price :</strong>
            <?php echo Form::number('price', null, array('placeholder' => '100000','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Duration :</strong>
            <?php echo Form::text('duration', null, array('placeholder' => '2 hari','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Status :</strong>
            <?php echo Form::text('status', null, array('placeholder' => 'Aktif/tidak','class' => 'form-control')); ?>

        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group <?php echo $errors->has('poster') ? 'has-error' : ''; ?>">
            <strong>Poster :</strong>
            <?php echo Form::file('poster'); ?>

            <?php echo Form::label('poster', 'Gambar Harus Memiliki Format ( jpg,jpeg,png )*'); ?>

        </div>
    </div>

    <!-- <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Foto:</strong>
            <?php echo Form::file('foto', null); ?>

        </div>
    </div> -->


    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>