<h1><b>HomeIsland</b></h1>
<h4>Information System Project</h4>

- Mobile Application using <b>IONIC 3</b>
- Dashboard Admin using <b>LARAVEL 5.5 & MYSQL</b>

<h3><b>Homeisland Team :</b></h3>

1. Guntur Putra Pratama as <b>Backend Developer <i>(Project Manager)</i></b>
2. Rakish Frisky as <b>Backend Developer</b>
3. Ryan Azrian as <b>Front Developer</b>
4. Wiranegara as <b>Front Developer</b>
