
--
-- Table structure for table `rgn_postcode`
--

CREATE TABLE `rgn_postcode` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'id entry',
  `postcode` int(10) UNSIGNED NOT NULL,
  `subdistrict_id` int(10) UNSIGNED DEFAULT NULL,
  `district_id` int(10) UNSIGNED DEFAULT NULL,
  `city_id` int(10) UNSIGNED DEFAULT NULL,
  `province_id` int(10) UNSIGNED DEFAULT NULL,
  `country_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='kodepos';

--
-- Indexes for table `rgn_postcode`
--
ALTER TABLE `rgn_postcode`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index2` (`postcode`),
  ADD KEY `index3` (`subdistrict_id`),
  ADD KEY `index4` (`district_id`),
  ADD KEY `index5` (`city_id`),
  ADD KEY `index6` (`province_id`),
  ADD KEY `index7` (`country_id`);

--
-- Constraints for table `rgn_postcode`
--
ALTER TABLE `rgn_postcode`
  ADD CONSTRAINT `fk_city_postcode` FOREIGN KEY (`city_id`) REFERENCES `rgn_city` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_country_postcode` FOREIGN KEY (`country_id`) REFERENCES `rgn_country` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_district_postcode` FOREIGN KEY (`district_id`) REFERENCES `rgn_district` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_province_postcode` FOREIGN KEY (`province_id`) REFERENCES `rgn_province` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_subdistrict_postcode` FOREIGN KEY (`subdistrict_id`) REFERENCES `rgn_subdistrict` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- AUTO_INCREMENT for table `religion`
--
ALTER TABLE `rgn_postcode`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id entry';

