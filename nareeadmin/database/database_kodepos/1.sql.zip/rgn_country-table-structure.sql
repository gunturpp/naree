
--
-- Table structure for table `rgn_country`
--

CREATE TABLE `rgn_country` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'id entry',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'nama negara',
  `abbreviation` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'nama singkat'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Negara';

--
-- Indexes for table `rgn_country`
--
ALTER TABLE `rgn_country`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index2` (`abbreviation`);

--
-- AUTO_INCREMENT for table `religion`
--
ALTER TABLE `rgn_country`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id entry';
