
--
-- Table structure for table `rgn_province`
--

CREATE TABLE `rgn_province` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'id entry',
  `number` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `abbreviation` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'id negara'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='provinsi';

--
-- Indexes for table `rgn_province`
--
ALTER TABLE `rgn_province`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index2` (`country_id`),
  ADD KEY `index3` (`abbreviation`),
  ADD KEY `index4` (`number`);

--
--
-- Constraints for table `rgn_province`
--
ALTER TABLE `rgn_province`
  ADD CONSTRAINT `fk_country_province` FOREIGN KEY (`country_id`) REFERENCES `rgn_country` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;


--
-- AUTO_INCREMENT for table `religion`
--
ALTER TABLE `rgn_country`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id entry';
