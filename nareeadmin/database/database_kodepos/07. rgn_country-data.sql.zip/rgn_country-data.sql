
--
-- Dumping data for table `rgn_country`
--

INSERT INTO `rgn_country` (`id`, `name`, `abbreviation`) VALUES
(1, 'Indonesia', 'ina');
