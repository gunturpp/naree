
--
-- Table structure for table `rgn_subdistrict`
--

CREATE TABLE `rgn_subdistrict` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'id entry',
  `number` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `district_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='kelurahan';

--
-- Indexes for table `rgn_subdistrict`
--
ALTER TABLE `rgn_subdistrict`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index2` (`district_id`),
  ADD KEY `index3` (`number`);

--
-- Constraints for table `rgn_subdistrict`
--
ALTER TABLE `rgn_subdistrict`
  ADD CONSTRAINT `fk_district_subdistrict` FOREIGN KEY (`district_id`) REFERENCES `rgn_district` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- AUTO_INCREMENT for table `religion`
--
ALTER TABLE `rgn_subdistrict`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id entry';


