
--
-- Table structure for table `rgn_city`
--

CREATE TABLE `rgn_city` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'id entry',
  `number` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `abbreviation` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `province_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='kota/kabupaten';

--
-- Indexes for table `rgn_city`
--
ALTER TABLE `rgn_city`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index2` (`province_id`),
  ADD KEY `index3` (`abbreviation`),
  ADD KEY `index4` (`number`);

--
-- Constraints for table `rgn_city`
--
ALTER TABLE `rgn_city`
  ADD CONSTRAINT `fk_province_city` FOREIGN KEY (`province_id`) REFERENCES `rgn_province` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;


--
-- AUTO_INCREMENT for table `religion`
--
ALTER TABLE `rgn_city`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id entry';

