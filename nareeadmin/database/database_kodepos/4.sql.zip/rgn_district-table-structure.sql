
--
-- Table structure for table `rgn_district`
--

CREATE TABLE `rgn_district` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'id entry',
  `number` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `city_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='kecamatan';

--
-- Indexes for table `rgn_district`
--
ALTER TABLE `rgn_district`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index2` (`city_id`),
  ADD KEY `index3` (`number`);

--
-- Constraints for table `rgn_district`
--
ALTER TABLE `rgn_district`
  ADD CONSTRAINT `fk_city_district` FOREIGN KEY (`city_id`) REFERENCES `rgn_city` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- AUTO_INCREMENT for table `religion`
--
ALTER TABLE `rgn_district`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'id entry';


